/* eslint-disable no-mixed-operators */
/* eslint-disable no-return-assign */
/* eslint-disable no-var */
import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShieldAlt } from '@fortawesome/free-solid-svg-icons';
import tw from 'twin.macro';
import GreyRowBox from '@/components/elements/GreyRowBox';
import getServerBanIp from '@/api/swr/getServerBanIp';
import { ServerBanIp } from '@/api/server/types';
import unbanip from '@/api/server/banip/unbanip';
import { ServerContext } from '@/state/server';
import useFlash from '@/plugins/useFlash';
import Button from '@/components/elements/Button';

interface Props {
    BanIp: ServerBanIp;
}

export default ({ BanIp }: Props) => {
    const { mutate } = getServerBanIp();
    const primaryAllocation = ServerContext.useStoreState(state => state.server.data!.allocations.filter(alloc => alloc.isDefault).map(
        allocation => allocation.port
    )).toString();
    const uuid = ServerContext.useStoreState(state => state.server.data!.uuid);
    const { clearAndAddHttpError } = useFlash();
    let city = BanIp.city as string;
    let countryname = BanIp.countryname as string;
    let region = BanIp.region as string;
    if (BanIp.city === null || BanIp.city === '') {
        city = 'Unknow';
    }
    if (BanIp.countryname === null || BanIp.countryname === '') {
        countryname = 'Unknow';
    }
    if (BanIp.region === null || BanIp.region === '') {
        region = 'Unknow';
    }

    const UnbanIP = () => {
        unbanip(uuid, BanIp.ip, primaryAllocation).then(() => { 
            mutate();
         }).catch(error => {
            clearAndAddHttpError({ key: 'banip', error });
        });
    };
    return (
        <GreyRowBox $hoverable={false} css={tw`flex-wrap md:flex-nowrap items-center mt-2`}>
            <div css={tw`flex items-center truncate w-full md:flex-1`}>
                <div title={BanIp.ip} >
                    {BanIp.ip}
                    <br/>
                    <p css={tw`text-sm text-neutral-500`}>{countryname !== 'Unknow' && <span>Contry: {countryname}</span>} <br/> {region !== 'Unknow' && <span>Region: {region}</span>}<br/>{city !== 'Unknow' && <span>City: {city}</span>}</p>
                </div>
            </div>
            <div css={tw`flex-1 md:flex-none md:w-48 mt-4 md:mt-0 md:ml-1 md:text-center`}>
                <p css={tw`text-2xs text-neutral-500 uppercase mt-1`}>Country flag</p>
                {countryname === 'Unknow' ?
                    <p title={countryname} >
                                                Unknow
                    </p>
                    :
                    <p title={countryname}>
                        <img src={`https://countryflagsapi.com/png/${BanIp.country?.toLowerCase()}`} css={tw`inline w-16 h-10`}></img>
                    </p>
                }
            </div>
            <div css={tw`mt-4 md:mt-0 ml-6`} style={{ marginRight: '-0.5rem' }}>
                <Button
                    type={'button'}
                    color={'red'}
                    isSecondary
                    onClick={UnbanIP}
                    title="Unban IP"
                >
                    <FontAwesomeIcon icon={faShieldAlt} /> UnBan
                </Button>
            </div>
        </GreyRowBox>
    );
};

